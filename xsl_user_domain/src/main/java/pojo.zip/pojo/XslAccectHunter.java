package pojo;

import java.util.Date;

public class XslAccectHunter {
    private String name;
    private String url;
    private Date accectDate;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Date getAccectDate() {
        return accectDate;
    }

    public void setAccectDate(Date accectDate) {
        this.accectDate = accectDate;
    }
}
