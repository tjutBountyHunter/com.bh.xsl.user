package pojo;

public class XslUserRegister {
    private Integer hunterid;
    private String userId;
    private String password;
    private Integer id;
    private Integer masterid;
    private String phone;
    private String name;
    private String sex;
    private String schoolinfo;
    private String college;
    private String major;
    private String schoolNumber;
    private String token;
    private String code;

	public Integer getHunterid() {
		return hunterid;
	}

	public void setHunterid(Integer hunterid) {
		this.hunterid = hunterid;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMasterid() {
		return masterid;
	}

	public void setMasterid(Integer masterid) {
		this.masterid = masterid;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getSchoolinfo() {
		return schoolinfo;
	}

	public void setSchoolinfo(String schoolinfo) {
		this.schoolinfo = schoolinfo;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getSchoolNumber() {
		return schoolNumber;
	}

	public void setSchoolNumber(String schoolNumber) {
		this.schoolNumber = schoolNumber;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
