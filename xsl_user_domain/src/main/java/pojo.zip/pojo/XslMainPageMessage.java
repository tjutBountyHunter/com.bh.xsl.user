package pojo;

public class XslMainPageMessage {
    private String name;
    private String sex;
    private Integer hunter_level;
    private Integer master_level;
    private String url;
    private String signature;
    private Integer credit;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getHunter_level() {
        return hunter_level;
    }

    public void setHunter_level(Integer hunter_level) {
        this.hunter_level = hunter_level;
    }

    public Integer getMaster_level() {
        return master_level;
    }

    public void setMaster_level(Integer master_level) {
        this.master_level = master_level;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Integer getCredit() {
        return credit;
    }

    public void setCredit(Integer credit) {
        this.credit = credit;
    }
}
